Licensed to Todt40.
https://github.com/Todt40/SmartDice